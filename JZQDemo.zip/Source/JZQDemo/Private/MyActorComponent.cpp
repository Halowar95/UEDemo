// Fill out your copyright notice in the Description page of Project Settings.


#include "MyActorComponent.h"
#include "Components/Button.h"
#include "Components/TextBlock.h"
#include "Components/Widget.h"
#include <string>
#include <algorithm>
#include "Engine/Engine.h"

// Sets default values for this component's properties
UMyActorComponent::UMyActorComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// ...
}


// Called when the game starts
void UMyActorComponent::BeginPlay()
{
	Super::BeginPlay();

	// ...
	
}


// Called every frame
void UMyActorComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// ...
}

FString UMyActorComponent::EnableFunc(FString s1, FString s2) {
	FString s3 = s1 + s2;
	return s3;
}

//ֻҪ��鵥���Խ��ߵ����и��ӵ���չ�����ɸſ�����ʤ�����
bool UMyActorComponent::CheckIsWin(bool isAI)
{
	int matchValue = isAI ? -1 : 1;
	int winValue = 3 * matchValue;
	int finalValue1 = 0;
	int finalValue2 = 0;;
	//��������Խ���
	for (int i = 0; i < iSideLength; i++)
	{
		finalValue1 += aPieces[i][i];
		finalValue2 += aPieces[i][iSideLength - i - 1];
	}
	if (finalValue1 == winValue || finalValue2 == winValue)
	{
		return true;
	}
	//���ͨ���ø��ӵĺ���&����
	for (int i = 0; i < iSideLength; i++)
	{
		if (aPieces[i][i] != matchValue)
		{
			continue;
		}
		finalValue1 = finalValue2 = 0;
		for (int j = 0; j < iSideLength; j++)
		{
			finalValue1 += aPieces[i][j];
			finalValue2 += aPieces[j][i];
		}
		if (finalValue1 == winValue || finalValue2 == winValue)
		{
			return true;
		}
	}
	return false;
}

bool UMyActorComponent::PlacingPieceToPos(int x, int y, bool isAI)
{
	if (x >= iSideLength || y >= iSideLength)
	{
		return false;
	}
	//AI����ѡ����Ч��λ
	bool isLegal = isAI || aPieces[x][y] == 0;
	if (isLegal)
	{
		int value = isAI ? -1 : 1;
		aPieces[x][y] = value;
		RoundStepPush(isAI);
		//UI����
		DrawPiece(x, y, value);
	}
	return isLegal;
}

void UMyActorComponent::RoundStepPush(bool isAI)
{
	FString str = FString::FromInt(iRound) + (isAI ? "isAI" : "notAI");
	if (CheckIsWin(isAI))
	{
		GameOver();
		return;
	}
	iCurChessPlayerID = isAI ? 1 : -1;
	if (isAI == bIsFirstToGo)
	{
		iRound++;
	}
	//�����ռ��յĸ���
	GetAllEmptyPieces();
	//�Ѿ�û�пյ����ƽ�ֽ���
	if (lPiecesRandom.Num() == 0)
	{
		GameOver(true);
		return;
	}
	if (!isAI)
	{
		//AIPlacingPieceSimple();
		AIPlacingPieceHard();
	}
}

void UMyActorComponent::GetAllEmptyPieces()
{
	lPiecesRandom.Empty();
	for (int i = 0; i < iSideLength; i++)
	{
		for (int j = 0; j < iSideLength; j++)
		{
			if (aPieces[i][j] == 0)
			{
				lPiecesRandom.Add(i * iSideLength + j + 1);
			}
		}
	}
}

void UMyActorComponent::AIPlacingPieceSimple()
{
	srand(time(0));
	int randomIndex = rand() % lPiecesRandom.Num();
	int randomIndexValue = lPiecesRandom[randomIndex];
	int randomRowIndex = floor((randomIndexValue - 1) / iSideLength);
	//AI����
	PlacingPieceToPos(randomRowIndex, randomIndexValue - randomRowIndex * iSideLength - 1, true);
}

//�����߼�+Ȩ�ط� 1=���Լ�ʤ�� 2=��������ֹ����ʤ�� 3=������ÿ���ߵ÷������һ���Ž⣬ͬ���£��С��ǡ���
void UMyActorComponent::AIPlacingPieceHard()
{
	//AI����ʱ���޷�����÷֣������
	if (iRound == 0 && !bIsFirstToGo)
	{
		AIPlacingPieceSimple();
		return;
	}
	//��ǰ���Ž�
	int curBestMove = lPiecesRandom[0];

	//��ǰ��ߵ÷�
	int maxScore = 0;
	//��ʣ��Ŀո����ҵ���ѡ���
	for (int i = 0; i < lPiecesRandom.Num(); i++)
	{
		int curRowIndex = floor((lPiecesRandom[i] - 1) / iSideLength);
		int curColumnIndex = lPiecesRandom[i] - curRowIndex * iSideLength - 1;
		//��ǰ�÷�
		int curScore = 0;
		//���ߵ÷�
		int curValue = 0;
		//����ڶԽ����ϣ�������Խ���
		//���
		if (curRowIndex == curColumnIndex)
		{
			for (int j = 0; j < iSideLength; j++)
			{
				curValue += aPieces[j][j];
			}
			//ֱ��ʤ��
			if (curValue - 1 == -iSideLength)
			{
				PlacingPieceToPos(curRowIndex, curColumnIndex, true);
				return;
			}
			//����ǶԷ�����ʤ��������߷֣���ֹ��ʤ��
			else if (curValue + 1 == iSideLength)
			{
				curScore = 2 * (iSideLength + iSideLength + 2);
			}
			else
			{
				curScore += std::max(-curValue, 0) ;
			}
		}
		curValue = 0;
		//�Ҳ�
		if (curRowIndex + curColumnIndex == iSideLength - 1)
		{
			for (int j = 0; j < iSideLength; j++)
			{
				curValue += aPieces[j][iSideLength - j - 1];
			}
			if (curValue - 1 == -iSideLength)
			{
				PlacingPieceToPos(curRowIndex, curColumnIndex, true);
				return;
			}
			else if (curValue + 1 == iSideLength)
			{
				curScore = 2 * (iSideLength + iSideLength + 2);
			}
			else
			{
				curScore += std::max(-curValue, 0);
			}
		}
		curValue = 0;
		//������
		for (int j = 0; j < iSideLength; j++)
		{
			curValue += aPieces[curRowIndex][j];
		}
		if (curValue - 1 == -iSideLength)
		{
			PlacingPieceToPos(curRowIndex, curColumnIndex, true);
			return;
		}
		else if (curValue + 1 == iSideLength)
		{
			curScore = 2 * (iSideLength + iSideLength + 2);
		}
		else
		{
			curScore += std::max(-curValue, 0);
		}
		curValue = 0;
		//�������
		for (int j = 0; j < iSideLength; j++)
		{
			curValue += aPieces[j][curColumnIndex];
		}
		if (curValue - 1 == -iSideLength)
		{
			PlacingPieceToPos(curRowIndex, curColumnIndex, true);
			return;
		}
		else if (curValue + 1 == iSideLength)
		{
			curScore = 2 * (iSideLength + iSideLength + 2);
		}
		else
		{
			curScore += std::max(-curValue, 0);
		}
		curValue = 0;

		FString str = FString::FromInt(curScore);

		//�޷���ʤ������ǰ��÷�ѡ����һ�����
		if (curScore > maxScore)
		{
			maxScore = curScore;
			curBestMove = lPiecesRandom[i];
		}
		else if (curScore == maxScore)
		{
			int curWeight = GetPosTypeWeights(curBestMove);
			int newWeight = GetPosTypeWeights(lPiecesRandom[i]);
			curBestMove = curWeight < newWeight ? lPiecesRandom[i] : curBestMove;
		}
	}
	//AI����
	int rowIndex = floor((curBestMove - 1) / iSideLength);
	int columnIndex = curBestMove - rowIndex * iSideLength - 1;
	PlacingPieceToPos(rowIndex, columnIndex, true);
}

int UMyActorComponent::GetPosTypeWeights(int index)
{
	if ((iSideLength * iSideLength + 1) / 2 - index == 0)
	{
		return 3;
	}
	else if(index == 1 || index == iSideLength * iSideLength ||
		index == iSideLength || index == 1 + (iSideLength * (iSideLength - 1)))
	{
		return 2;
	}
	return 1;
}

void UMyActorComponent::GameStart()
{
	for (int i = 0; i < iSideLength; i++)
	{
		for (int j = 0; j < iSideLength; j++)
		{
			aPieces[i][j] = 0;
			DrawPiece(i, j, 0);
		}
	}
	GetAllEmptyPieces();

	if (bIsFirstToGo)
	{
		iCurChessPlayerID = 1;
	}
	else
	{
		iCurChessPlayerID = -1;
		//AIPlacingPieceSimple();
		AIPlacingPieceHard();
	}
	iRound = 0;
}

void UMyActorComponent::DrawPiece(int x, int y, int colorIdx)
{
	if (myWidget) 
	{
		int buttonIdx = x * iSideLength + y + 1;
		FString str = "Button" + FString::FromInt(buttonIdx);
		auto button = Cast<UButton>(myWidget->GetWidgetFromName(FName(*str)));
		if (button)
		{
			if (colorIdx == 1)
				button->SetBackgroundColor(FColor::Green);
			else if (colorIdx == -1)
				button->SetBackgroundColor(FColor::Red);
			else
				button->SetBackgroundColor(FColor::White);
		}
	}

}

void UMyActorComponent::GameOver(bool isForceEnd)
{
	MoveTheCurtain(false);
	FString str = "TextGameResult";
	auto text = Cast <UTextBlock>(myWidget->GetWidgetFromName(FName(*str)));
	if (isForceEnd)
	{
		text->SetText(FText::FromString("Draw Game!"));
	}
	else if (iCurChessPlayerID == 1)
	{
		text->SetText(FText::FromString("Winner!"));
	}
	else
	{
		text->SetText(FText::FromString("Lost..."));
	}
}

void UMyActorComponent::SwitchFirstPlayer()
{
	bIsFirstToGo = !bIsFirstToGo;
}

void UMyActorComponent::MoveTheCurtain(bool isClose)
{
	FString str = "Curtain";
	auto overLay = Cast <UWidget> (myWidget->GetWidgetFromName(FName(*str)));
	if (overLay)
	{
		if (isClose)
		{
			overLay->SetVisibility(ESlateVisibility::Collapsed);
		}
		else
		{
			overLay->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		}
	}
}

